import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ladies-outwear',
  templateUrl: './ladies-outwear.component.html',
  styleUrls: ['./ladies-outwear.component.css']
})
export class LadiesOutwearComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
