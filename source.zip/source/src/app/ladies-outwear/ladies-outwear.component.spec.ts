import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LadiesOutwearComponent } from './ladies-outwear.component';

describe('LadiesOutwearComponent', () => {
  let component: LadiesOutwearComponent;
  let fixture: ComponentFixture<LadiesOutwearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LadiesOutwearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LadiesOutwearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
