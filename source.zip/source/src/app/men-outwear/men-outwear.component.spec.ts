import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MenOutwearComponent } from './men-outwear.component';

describe('MenOutwearComponent', () => {
  let component: MenOutwearComponent;
  let fixture: ComponentFixture<MenOutwearComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MenOutwearComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MenOutwearComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
