import { Component, OnInit } from '@angular/core';
import { MenoutwearService } from '../menoutwear.service';
import { ActivatedRoute, ParamMap } from "@angular/router";

@Component({
  selector: 'app-men-outwear',
  templateUrl: './men-outwear.component.html',
  styleUrls: ['./men-outwear.component.css']
})
export class MenOutwearComponent implements OnInit {

	menoutwearData: any;
	constructor(private menoutwearSer:MenoutwearService,private route: ActivatedRoute) {
		this.getData();
		
	}
	ngOnInit(): void {
	}
	getData(){
		this.menoutwearSer.getData().subscribe((data:any)=>{
			this.menoutwearData = data;
			console.log(this.menoutwearData);
		});
	}

}
