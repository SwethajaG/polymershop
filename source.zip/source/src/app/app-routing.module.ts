import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MenOutwearComponent } from './men-outwear/men-outwear.component';
import { LadiesOutwearComponent } from './ladies-outwear/ladies-outwear.component';
import { ItempageComponent } from './itempage/itempage.component';
import { CartComponent } from './cart/cart.component';

const routes: Routes = [{
    path: "listmensoutwear",
    component: MenOutwearComponent
  },
  {
    path: "listladiesoutwear",
    component: LadiesOutwearComponent
  },
  {
    path: "itemdetailpage/:id",
    component: ItempageComponent
  },
  {
    path: "cartdetails",
    component: CartComponent
  }
  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
