import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DialogModule } from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MenOutwearComponent } from './men-outwear/men-outwear.component';
import { LadiesOutwearComponent } from './ladies-outwear/ladies-outwear.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { ItempageComponent } from './itempage/itempage.component';
import { CartComponent } from './cart/cart.component';

@NgModule({
  declarations: [
    AppComponent,
    MenOutwearComponent,
    LadiesOutwearComponent,
    HomeComponent,
    ItempageComponent,
    CartComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	FormsModule,
	DialogModule,
	BrowserAnimationsModule,
    NgbModule,
	HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
