import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap } from "@angular/router";
import { MenoutwearService } from '../menoutwear.service';

@Component({
  selector: 'app-itempage',
  templateUrl: './itempage.component.html',
  styleUrls: ['./itempage.component.css']
})
export class ItempageComponent implements OnInit {

	singleItemDetails:any;
	singlecartDetails:any;
	displayCartMessage:boolean = false;
	
	constructor(private route: ActivatedRoute,private menoutwearSer:MenoutwearService) { }

	ngOnInit(): void {
		this.getSingleItemDetails(this.route.snapshot.params.id);
	}
	
	getSingleItemDetails(id:any){
		this.menoutwearSer.getSingleItem(id).subscribe((data:any)=>{
			this.singleItemDetails = data;
		});
	}
	
	openCartMessage(data:any){
		this.checkCart(data);
		this.addToCart(data);
	}
	addToCart(data:any){
		data.quantity = 1;
		this.menoutwearSer.addToCart(data).subscribe((data:any)=>{	
		});
		this.displayCartMessage = true;
	}
	checkCart(cartdata:any){
		debugger;
		this.menoutwearSer.getCartDatabyId(cartdata.id).subscribe((data:any)=>{
			this.updateCart(data);
		});
	}
	updateCart(cart:any){
		debugger;
		cart.quantity +=1;
		this.menoutwearSer.updateCart(cart,cart.id).subscribe((data:any)=>{
	
		});
	}
}
