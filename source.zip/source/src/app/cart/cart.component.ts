import { Component, OnInit } from '@angular/core';
import { MenoutwearService } from '../menoutwear.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

	allCartData:any;
	totalAmount: number = 0;
	totalCartItems: number = 0;
	currQty:any;
	currRowTotal: number = 0;
	
	
	constructor(private menoutwearSer:MenoutwearService) { 
		this.getAllCartDetails();
		
	}

	ngOnInit(): void {
		
	}

	getAllCartDetails(){
		this.menoutwearSer.getAllCartData().subscribe((data:any)=>{
			this.allCartData = data;
			this.getTotal();
		});
	}
	
	getTotal(){
		this.totalAmount = 0;
		for(let i=0;i<this.allCartData.length;i++){
			this.totalCartItems += this.allCartData[i].quantity;
			this.totalAmount += this.allCartData[i].rate * this.allCartData[i].quantity;
		}
		console.log(this.totalCartItems);
		//sessionStorage.setItem('cartTotal' , this.totalCartItems);
	}
	
	
	deleteItem(id:any){
		this.menoutwearSer.deleteCart(id).subscribe((data:any)=>{
			this.getAllCartDetails();
		});
	}
	
	itemQty(data:any,cart:any){
		
		//this.currQty = {"quantity":data.target.value}
		
	
		
		/*this.currRowTotal = data.target.value * rate;
		this.currQty = data.target.value;*/
		
		cart.quantity = data.target.value;
		debugger;
		this.menoutwearSer.updateCartQty(cart,cart.id).subscribe((data:any)=>{
			this.getAllCartDetails();
			this.getTotal();
		});
		
	}

}
