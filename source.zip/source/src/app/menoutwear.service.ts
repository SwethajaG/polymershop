import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MenoutwearService {
	currItemUrl = '';
	url = "http://localhost:3000/posts";
	cartUrl = "http://localhost:3000/cart";
	getCartById :any;
	updateCartUrl:any;
	deleteurl:any;
	
	constructor(private http: HttpClient) { }
	
	getData(){
		return this.http.get(this.url);
	}
	
	getSingleItem(id:any){
		this.currItemUrl = this.url + "/" + id;
		return this.http.get(this.currItemUrl);
	}
	
	getAllCartData(){
		return this.http.get(this.cartUrl);
	}
	
	addToCart(data: any){
		return this.http.post(this.cartUrl,data);
	}
	
	getCartDatabyId(id:any){
		debugger;
		this.getCartById = this.cartUrl + '/' + id;
		return this.http.get(this.getCartById);
	}
	
	updateCart(data:any , id:any){
		this.updateCartUrl = this.cartUrl + '/' + id;
		return this.http.put(this.updateCartUrl,data);
	}
	
	deleteCart(id:any){
		this.deleteurl = this.cartUrl + '/' + id;
		return this.http.delete(this.deleteurl);
	}
	
	updateCartQty(data:any , id:any){
		this.updateCartUrl = this.cartUrl + '/' + id;
		return this.http.put(this.updateCartUrl,data);
	}
	
}
