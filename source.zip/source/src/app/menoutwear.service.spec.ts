import { TestBed } from '@angular/core/testing';

import { MenoutwearService } from './menoutwear.service';

describe('MenoutwearService', () => {
  let service: MenoutwearService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MenoutwearService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
